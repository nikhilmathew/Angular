var res = {
	akashi_ttf: "res/Akashi.ttf",
	bg_starfield1_jpg: "res/bg_starfield1.jpg",
	bg_starfield2_png: "res/bg_starfield2.png",
	spritesheet_plist: "res/spritesheet.plist",
	spritesheet_png: "res/spritesheet.png",
};

var g_resources = [];

for (var i in res) {
	g_resources.push(res[i]);
}