package sfs2x.extensions.games.tris;

public enum GameState
{
	RUNNING,
	END_WITH_WINNER,
	END_WITH_TIE;
}
