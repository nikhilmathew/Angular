The Tris example comes with an Extension provided in two versions: Java and JavaScript (Tris and Tris-JS respectively). The two versions are contained in the "deploy/extensions/" folder.
You can choose which one to use by enabling the corresponding constants in the main.js file under "deploy/client/scripts/".
The source code of the Java Extension is available in the "source" folder.